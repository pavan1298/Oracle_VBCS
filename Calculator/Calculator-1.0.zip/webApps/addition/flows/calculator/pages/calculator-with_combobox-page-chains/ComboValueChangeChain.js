define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     */
    async run(context, { event, previousValue, value, updatedFrom }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      switch (value) {
        case '+': {
          $variables.var_result = $variables.var_first_value + $variables.var_second_value;
          break;
        }
        case '-': {
          $variables.var_result = $variables.var_first_value - $variables.var_second_value;
          break;
        }
        case '*': {
          $variables.var_result = $variables.var_first_value * $variables.var_second_value;
          break;
        }
        case '/': {
          $variables.var_result = $variables.var_first_value / $variables.var_second_value;
          break;
        }
        case '%': {
          $variables.var_result = $variables.var_first_value % $variables.var_second_value;
          break;
        }
        default:
          break;
      }
    }
  }

  return ComboValueChangeChain;
});
