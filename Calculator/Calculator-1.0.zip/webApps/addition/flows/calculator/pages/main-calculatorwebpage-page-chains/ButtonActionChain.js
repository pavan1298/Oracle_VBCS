define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Assign Value to var_result
      $variables.var_result = $variables.var_num1+$variables.var_num2;

      await Actions.fireNotificationEvent(context, {
        summary: 'Addition of ' +$variables.var_num1+ ' and ' + $variables.var_num2 + ' is ' + $variables.var_result,
        type: 'info',
      });
    }
  }

  return ButtonActionChain;
});
